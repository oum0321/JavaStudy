package com.book45.mapper;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.book45.domain.BookReviewVO;
import com.book45.domain.Criteria;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BookReviewMapperTests {

	private Long[] isbnArr = {9788954699914L, 9788901260716L};
	@Autowired
	private BookReviewMapper mapper;
	
	@Test
	public void testMapper() {
		
		log.info(mapper);
	}
	
	@Test
	public void testCreate() {
		
		Long isbn = 9788954699914L;
		String id = "member";
		String nickname = "가상닉네임2";
		String content = "리뷰테스트2";
		
		
			
		BookReviewVO vo = new BookReviewVO();
		
		vo.setIsbn(isbn);
		vo.setId(id);
		vo.setNickname(nickname);
		vo.setContent(content);
		
		mapper.insert(vo);
		
	}
	
	@Test 
	public void testRead() {
		
		Long targetNum = 1L;
		
		BookReviewVO vo = mapper.read(targetNum);
		
		log.info(vo);
				
	}
	
	@Test
	public void testDelete() {
		
		Long targetNum = 1L;
		
		mapper.delete(targetNum);
	}
	
	@Test
	public void testUpdate() {
		
		Long targetNum = 4L;
		
		BookReviewVO vo = mapper.read(targetNum);
		
		vo.setContent("수정됨");
		
		int count = mapper.update(vo);
		
		log.info("수정 확인 : " +count);
	}
	
	@Test
	public void testList() {
		
		Criteria cri = new Criteria(2, 10);
		
		List<BookReviewVO> reviews = mapper.getListWithPaging(cri, isbnArr[0]);
		
		reviews.forEach(review ->log.info(review));
	}
	
	
}
