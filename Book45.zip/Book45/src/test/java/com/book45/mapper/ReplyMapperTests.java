package com.book45.mapper;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.book45.domain.Criteria;
import com.book45.domain.ReplyVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	
	//먼저 해당 게시물이 있는지 확인
	private Long[] num2Arr = {2L, 3L, 4L, 5L, 6L};
	
	@Autowired
	private ReplyMapper mapper;
	
	//ReplyMapper가 제대로 작동하는지 테스트
	@Test
	public void testReply() {
		
		log.info(mapper);
	}
	
	//댓글을 해당 게시판에 생성하기 위해서 만든 테스트
	@Test
	public void testCreate() {
		
		IntStream.rangeClosed(1, 10).forEach(i -> {
			
			ReplyVO vo = new ReplyVO();
			
//			vo.setBoardNum(num2Arr[i % 5]);
			vo.setMemberId("user");
			vo.setNickname("user");
			vo.setContent("댓글 테스트 내용" + i);
			
			mapper.insert(vo);
			
			log.info("vo : " + vo);
		});
	}
	
	//해당 댓글을 찾기 위해서 만든 테스트
	@Test
	public void testRead() {
		
		Long targetNum = 2L;
		
		ReplyVO vo = mapper.read(targetNum);
		
		log.info(vo);
	}
	
	//해당 댓글을 삭제 하기 위해서 만든 테스트
	@Test
	public void testDelete() {
		
		Long targetNum = 1L;
		
		mapper.delete(targetNum);
	}
	
	//해당 댓글을 수정 하기 위해서 만든 테스트
	@Test
	public void testUpdate() {
		
		Long targetNum = 2L;
		
		ReplyVO vo = mapper.read(targetNum);
		
		vo.setContent("댓글 수정 테스트");
		
		int count = mapper.update(vo);
		
		log.info("upate count : " + count);
	}
	
//	//해당 게시글에 있는 댓글 목록을 보여주기 위해서 만든 테스트
//	@Test
//	public void testList() {
//		
//		Criteria cri = new Criteria();
//		
//		//int[] num2Arr 배열에 첫번째 게시물에 있는 댓글
//		List<ReplyVO> replyList = mapper.getListWithPaging(cri, num2Arr[0]);
//		
//		replyList.forEach(reply -> log.info(reply));
//	}

}
