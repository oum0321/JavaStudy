package com.book45.domain;

import java.util.Date;

import lombok.Data;

@Data
public class BookReviewVO {

	private Long num;
	private Long isbn;
	
	private String id;
	private String nickname;
	private String content;
	
	private Date writeDate;
	private Date updateDate;
}
