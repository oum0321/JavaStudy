package com.book45.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class OrderDTO {
	private String orderNum;
	private String id;
	private String name;
	private String zipCode;
	private String addressRoad;
	private String addressDetail;
	private String phone;
	
	private String orderState;
	private List<OrderItemDTO> orderItem;
	private int usePoint;
	private Date orderDate;
	private int deliverCost; 

	private int totalPrice;
	private int finalTotalPrice;
	
	public void getOrderPriceInfo() {
		
		for(OrderItemDTO orderItem : orderItem) {
			totalPrice += orderItem.getTotalPrice();
		}
	}
}
