package com.book45.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ReplyVO {
	
	private Long replyNum;
	private int boardNum;
	private String memberId;
	private String nickname;
	private String content;
	private Date replyDate;
	private Date replyUpdate;
	//private boolean secret;

}
