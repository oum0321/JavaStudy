package com.book45.domain;

import java.util.Date;

import lombok.Data;

@Data
public class AlbumReviewVO {

	
	private Long num;
	private Long productNum;
	
	private String id;
	private String nickname;
	private String content;
	
	private Date writeDate;
	private Date updateDate;
}
