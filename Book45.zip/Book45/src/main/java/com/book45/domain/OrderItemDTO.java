package com.book45.domain;

import lombok.Data;

@Data
public class OrderItemDTO {
	private String orderItemNum;	
	private String orderNum;  //orders테이블의 기본키. 외래키로 받아오는 값
	private Long isbn;
	private Long productNum;
	private int amount;
	private int price;
	private int albumPrice;
	private int totalPrice; //나중에 빠질 수도 있음
	private String phone;
	
	
	public void initTotal() {
		this.totalPrice = this.price * this.amount + this.albumPrice * this.amount;
	}
}
