package com.book45.domain;

import java.util.List;

import lombok.Data;

/* 뷰에서 전송한 데이터를 전달받을 객체가 될 클래스 .상품 데이터를 담을 클래스*/
@Data
public class OrderPageItemDTO {
	
	//뷰에서 전달받을 값: isbn, productNum, amount
	private Long isbn;
	private Long productNum;
	private int amount;
	
	//DB에서 꺼내올 값
	private String title;
	private int price;
	private String pictureUrl;
	
	//앨범
	private String albumTitle;
	private int albumPrice;
	private String albumPictureurl;
	
	//만들어 낼 값
	private int totalPrice;
	private int point; //한 개의 상품 구매로 받을 수 있는 포인트
	private int totalPoint; //총 적립될 포인트
	
	
	public void initTotal() {
		this.totalPrice = this.price * this.amount + this.albumPrice * this.amount;
		this.point = (int)(Math.floor(this.price * 0.1));
		this.totalPoint = this.point * this.amount;
	}
}
