package com.book45.domain;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class OrdersVO {

	private String orderNum;
	private String id;
	private String name;
	private String phone;
	private Date orderDate;
	private String zipCode;
	private String addressRoad;
	private String addressDetail;
	private String orderState;
	private int deliverCost;
	
	private List<OrderItemDTO> orderItem;
	private int totalPrice;
	private int finalTotalPrice;
}
