package com.book45.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.book45.domain.BookReviewVO;
import com.book45.domain.Criteria;

public interface BookReviewMapper {

	public int insert(BookReviewVO vo);
	
	public BookReviewVO read(Long num);
	
	public int delete (Long num);
	
	public int update (BookReviewVO vo);
	
	public List<BookReviewVO> getListWithPaging(
			@Param("cri") Criteria cri,
			@Param("isbn") Long isbn);
	
	public int getCountByIsbn(Long isbn);
	
}
