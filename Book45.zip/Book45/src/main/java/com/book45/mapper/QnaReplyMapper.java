package com.book45.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.book45.domain.Criteria;
import com.book45.domain.QnaReplyVO;

public interface QnaReplyMapper {
	
	public int insert(QnaReplyVO qrVo);
	public QnaReplyVO read(Long num);
	public int delete(Long num);
	public int update(QnaReplyVO qrVo);
	public List<QnaReplyVO> getListWithPaging(@Param("cri") Criteria cri, @Param("qNum") Long qNum);
	public int getCountByQnum(Long qnum);
	
}
