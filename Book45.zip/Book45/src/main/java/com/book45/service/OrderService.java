package com.book45.service;

import java.util.List;

import com.book45.domain.OrderDTO;
import com.book45.domain.OrderPageItemDTO;

public interface OrderService {
	public List<OrderPageItemDTO> getBooksInfo(List<OrderPageItemDTO> orders);
	
	public List<OrderPageItemDTO> getAlbumsInfo(List<OrderPageItemDTO> orders);
	
	public void bookOrder(OrderDTO ord);
	
	public void albumOrder(OrderDTO ord);
}
