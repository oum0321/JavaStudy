package com.book45.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book45.domain.BookVO;
import com.book45.domain.CartDTO;
import com.book45.domain.MemberVO;
import com.book45.domain.OrderDTO;
import com.book45.domain.OrderItemDTO;
import com.book45.domain.OrderPageItemDTO;
import com.book45.mapper.BookMapper;
import com.book45.mapper.CartMapper;
import com.book45.mapper.MemberMapper;
import com.book45.mapper.OrderMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderMapper ordersMapper;

	@Autowired
	private MemberMapper memberMapper;
	
	@Autowired
	private CartMapper cartMapper;
	
	@Autowired
	private BookMapper bookMapper;

	@Override
	public List<OrderPageItemDTO> getBooksInfo(List<OrderPageItemDTO> orders) {
		List<OrderPageItemDTO> result = new ArrayList<>();
		
		for (OrderPageItemDTO opi : orders) {
			OrderPageItemDTO booksInfo = ordersMapper.getBooksInfo(opi.getIsbn());
			booksInfo.setAmount(opi.getAmount());
			booksInfo.initTotal();
			result.add(booksInfo);
		}
		
		return result;
	}
	
	@Override
	public List<OrderPageItemDTO> getAlbumsInfo(List<OrderPageItemDTO> orders) {
		List<OrderPageItemDTO> result = new ArrayList<>();
		
		for (OrderPageItemDTO opi : orders) {
			OrderPageItemDTO albumsInfo = ordersMapper.getAlbumsInfo(opi.getProductNum());
			albumsInfo.setAmount(opi.getAmount());
			albumsInfo.initTotal();
			result.add(albumsInfo);
		}
		return result;
	}
	
	@Override
	@Transactional
	public void bookOrder(OrderDTO ord) {
		/* 사용할 데이터가져오기 */
		/* 회원 정보 */
		log.info("=====확인중=====" + ord);
		MemberVO member = memberMapper.getMember(ord.getId());
		log.info("=====확인중=====" + member);
		/* 주문 정보 */
		List<OrderItemDTO> ords = new ArrayList<>();
		for(OrderItemDTO oit : ord.getOrderItem()) { //여기서 널포인트 때문에 오류
			OrderItemDTO orderItem = ordersMapper.getOrderBooksInfo(oit.getIsbn());
			orderItem.setAmount(oit.getAmount());
			orderItem.initTotal();
			ords.add(orderItem);
		}
		ord.setOrderItem(ords);
		ord.getOrderPriceInfo();
		
		/* DB주문, 주문상품 넣기 */
		/* orderID 만들기 및 OrdeDTO객체 orderId에 저장 */
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("_yyyyMMdd");
		String orderNum = member.getId() + format.format(date);
		ord.setOrderNum(orderNum);
		
		/* db넣기 */
		ordersMapper.enrollOrder(ord);
		for(OrderItemDTO oit : ord.getOrderItem()) {
			oit.setOrderNum(orderNum);
			ordersMapper.enrollOrderBookItem(oit);
		}
		
		/* 비용 포인트 변동 적용 */
		/* 포인트 차감, 포인트 증가 & 변동 포인트(point) Member객체 적용 */
		int calPoint = member.getPoint();
		calPoint = calPoint - ord.getUsePoint();	// 기존 포인트 - 사용 포인트
		member.setPoint(calPoint);
	
		/* 변동 돈, 포인트 DB 적용 */
		ordersMapper.deductPoint(member);
		
		/* 재고 변동 적용 */
		for(OrderItemDTO oit : ord.getOrderItem()) {
			/* 변동 재고 값 구하기 */
			BookVO book = bookMapper.getGBooksInfo(oit.getIsbn());
			book.setStock(book.getStock() - oit.getAmount());
			/* 변동 값 DB 적용 */
			ordersMapper.deductBookStock(book);
		}
		
		/* 장바구니 제거 */
		for(OrderItemDTO oit : ord.getOrderItem()) {
			CartDTO dto = new CartDTO();
			dto.setId(ord.getId());
			dto.setIsbn(oit.getIsbn());
			
			cartMapper.deleteOrderCart(dto);		
		
		}
	}
	
	
	@Override
	@Transactional
	public void albumOrder(OrderDTO ord) {
		/* 사용할 데이터가져오기 */
		/* 회원 정보 */
		MemberVO member = memberMapper.getMember(ord.getId());
		/* 주문 정보 */
		List<OrderItemDTO> ords = new ArrayList<>();
		for(OrderItemDTO oit : ord.getOrderItem()) {
			OrderItemDTO orderItem = ordersMapper.getOrderAlbumsInfo(oit.getProductNum());
			orderItem.setAmount(oit.getAmount());
			orderItem.initTotal();
			ords.add(orderItem);
		}
		ord.setOrderItem(ords);
		ord.getOrderPriceInfo();
	}
	
	
	
}
