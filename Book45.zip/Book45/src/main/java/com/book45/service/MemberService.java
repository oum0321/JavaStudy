package com.book45.service;

import java.util.List;

import com.book45.domain.Criteria;
import com.book45.domain.MemberVO;


public interface MemberService {
	//로그인
	public MemberVO memberLogin(MemberVO member) throws Exception;
	//회원가입
	public void memberJoin(MemberVO member) throws Exception;
	//아이디 중복체크
	public int idCheck(String id) throws Exception;
	
	public int nickNameCheck(String nickname) throws Exception;
	
	public MemberVO getMember(String id);
	//마이페이지 회원정보 수정
	public int updateMypage(MemberVO member);
	//회원탈퇴
	public int deleteMember(String id);
	//관리자 회원리스트
	public List<MemberVO> getMemberList();
	//관리자 회원정보 수정
	public int updateByAdmin(MemberVO member);
	//주문리스트
	//public List<OrderDTO> getOrderList(Criteria cri);
	
	//public int getOrderTotal(Criteria cri);
}
