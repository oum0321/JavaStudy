package com.book45.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book45.domain.Criteria;
import com.book45.domain.QnaReplyPageDTO;
import com.book45.domain.QnaReplyVO;
import com.book45.mapper.QnaMapper;
import com.book45.mapper.QnaReplyMapper;

@Service
public class QnaReplyServiceImpl implements QnaReplyService {
	
	@Autowired
	private QnaReplyMapper mapper;
	
	@Autowired
	private QnaMapper qnaMapper;
	
	@Override
	public int register(QnaReplyVO qrVo) {
		
		qnaMapper.updateReplyCnt(qrVo.getQNum(), 1);
		return mapper.insert(qrVo);
	}

	@Override
	public QnaReplyVO get(Long num) {
		return mapper.read(num);
	}

	@Override
	public int modify(QnaReplyVO qrVo) {
		return mapper.update(qrVo);
	}


	@Override
	public List<QnaReplyVO> getList(Criteria cri, Long qNum) {
		return mapper.getListWithPaging(cri, qNum);
	}
	


	@Override
	public int remove(Long num) {
		QnaReplyVO qrVo = mapper.read(num);
		return mapper.delete(num);
	}

	@Override
	public QnaReplyPageDTO getListPage(Criteria cri, Long qNum) {
		return new QnaReplyPageDTO(
				mapper.getCountByQnum(qNum),
				mapper.getListWithPaging(cri, qNum)
				);
	}

	
}
