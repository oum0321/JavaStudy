package com.book45.service;

import java.util.List;

import com.book45.domain.AlbumReviewPageDTO;
import com.book45.domain.AlbumReviewVO;
import com.book45.domain.Criteria;

public interface AlbumReviewService {

	public int register(AlbumReviewVO vo);
	
	public AlbumReviewVO get(Long num);
	
	public int modify(AlbumReviewVO vo);
	
	public int remove(Long num);
	
	public List<AlbumReviewVO> getList(Criteria cri, Long productNum);
	
	public AlbumReviewPageDTO getListPage(Criteria cri, Long productNum);
	
	//public int checkAlbumReview(AlbumReviewVO vo);
}
