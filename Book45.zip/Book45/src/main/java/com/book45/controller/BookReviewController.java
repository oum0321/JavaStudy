package com.book45.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.book45.domain.BookReviewPageDTO;
import com.book45.domain.BookReviewVO;
import com.book45.domain.Criteria;
import com.book45.service.BookReviewService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/bookreviews/")
@RestController
@Log4j
@AllArgsConstructor
public class BookReviewController {

	@Autowired
	private BookReviewService service;
	
	@PostMapping(value="/new", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String>register(@RequestBody BookReviewVO vo) {
		
		log.info("BookReviewVO register: " + vo );
		
		int insertCount = service.register(vo);
		
		log.info("BookReview Insert Count : " +insertCount);
		
		return insertCount == 1 
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping(value = "/pages/{isbn}/{page}",produces= {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<BookReviewPageDTO> getList(
			@PathVariable("page") int page,
			@PathVariable("isbn") Long isbn) {
		
			
			Criteria cri = new Criteria(page,10);
			
			log.info("도서리뷰 컨트롤러 리스트 : " +isbn);
			
			return new ResponseEntity<>(service.getListPage(cri, isbn),HttpStatus.OK);
	}
	
	@GetMapping(value = "/{num}", produces= {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<BookReviewVO> get(@PathVariable("num") Long num) {
		
		log.info("Get: " +num);
		
		return new ResponseEntity<>(service.get(num), HttpStatus.OK);
	}
	
	@DeleteMapping(value= "/{num}", produces = {MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> remove(@PathVariable("num") Long num) {
		
		log.info("remove : "+num);
		
		return service.remove(num) == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(method = { RequestMethod.PUT, RequestMethod.PATCH }, value = "/{num}", consumes = "application/json",
			produces = {MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> modify(

			@RequestBody BookReviewVO vo,
			@PathVariable("num") Long num) {

		vo.setNum(num);

		log.info("num : " +num);

		log.info("modify : " +vo);

		return service.modify(vo) == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
}
	
}
