package com.book45.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.book45.domain.BookVO;
import com.book45.domain.Criteria;
import com.book45.domain.PageDTO;
import com.book45.service.BookService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/book/*")
@AllArgsConstructor
public class BookController {

	private BookService service;
	
	@GetMapping("/list")
	public void list(Criteria cri, Model model) {
		
		log.info("list : "+ cri);
		model.addAttribute("list", service.getList(cri));
		
		int total = service.getTotal(cri);
		
		log.info("total : " +total);
		
		model.addAttribute("pageMaker", new PageDTO(cri,total)); 
	}
	
	@GetMapping("/register")
	public void register() {}
	
	@PostMapping("/register")
	public String register(BookVO book, RedirectAttributes rttr) {
		
		log.info("register : " +book);
		
		service.register(book);
		
		rttr.addFlashAttribute("result : " +book.getNum());
		
		return "redirect:/book/list";
	}
	
	@GetMapping({"/get","/modify"})
	public void get(@RequestParam Long isbn, @ModelAttribute("cri") Criteria cri ,Model model) {
		log.info("/get or /modify");
		model.addAttribute("book", service.get(isbn));
	}
	
	@PostMapping("/modify")
	public String modify(BookVO book, @ModelAttribute("cri") Criteria cri ,RedirectAttributes rttr) {
		log.info("modify : "+book);
		
		if(service.modify(book)) {
			rttr.addFlashAttribute("result", "modify");
		}
		
		
		return "redirect:/book/list" +cri.getListLink();
	}
	
	@PostMapping("/remove")
	public String remove(@RequestParam("isbn") Long isbn,@ModelAttribute("cri") Criteria cri , RedirectAttributes rttr) {
		log.info("remove : " +isbn);
		
		if(service.remove(isbn)) {
			rttr.addFlashAttribute("result","delete");
		}
		
		return "redirect:/book/list" +cri.getListLink();
	}
	
	
	
}
