package com.book45.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.book45.domain.AlbumReviewPageDTO;
import com.book45.domain.AlbumReviewVO;
import com.book45.domain.Criteria;
import com.book45.service.AlbumReviewService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/albumreviews/")
@RestController
@Log4j
@AllArgsConstructor
public class AlbumReviewController {

	@Autowired
	private AlbumReviewService service; 
	
	@PostMapping(value="/new", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String>register(@RequestBody AlbumReviewVO vo) {
		
		log.info("AlbumReviewVO register: " + vo );
		
		int insertCount = service.register(vo);
		
		log.info("AlbumReview Insert Count : " +insertCount);
		
		return insertCount == 1 
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
//	@GetMapping(value = "/pages/{productNum}/{page}",produces= {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
//	public ResponseEntity<List<AlbumReviewVO>> getList(
//			@PathVariable("page") int page,
//			@PathVariable("productNum") Long productNum) {
//		
//			log.info("getList.....");
//			Criteria cri = new Criteria(page,10);
//			
//			log.info(cri);
//			
//			return new ResponseEntity<>(service.getList(cri, productNum),HttpStatus.OK);
//	}
	
	@GetMapping(value = "/{num}", produces= {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<AlbumReviewVO> get(@PathVariable("num") Long num) {
		
		log.info("Get: " +num);
		
		return new ResponseEntity<>(service.get(num), HttpStatus.OK);
	}
	
	@DeleteMapping(value= "/{num}", produces = {MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> remove(@PathVariable("num") Long num) {
		
		log.info("remove : "+num);
		
		return service.remove(num) == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@RequestMapping(method = { RequestMethod.PUT, RequestMethod.PATCH }, value = "/{num}", consumes = "application/json",
								produces = {MediaType.TEXT_PLAIN_VALUE })
	public ResponseEntity<String> modify(
			
			@RequestBody AlbumReviewVO vo,
			@PathVariable("num") Long num) {
		
		vo.setNum(num);
		
		log.info("num : " +num);
		
		log.info("modify : " +vo);
		
		return service.modify(vo) == 1
				? new ResponseEntity<>("success", HttpStatus.OK)
				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping(value = "/pages/{productNum}/{page}", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<AlbumReviewPageDTO> getList(@PathVariable("page") int page, @PathVariable("productNum") Long productNum ) {
		
		Criteria cri = new Criteria(page, 10);
		
		log.info("get AlbumReview List productNum : + " +productNum);
		
		log.info("cri : " +cri);
		
		return new ResponseEntity<>(service.getListPage(cri, productNum),HttpStatus.OK);
	}
	
//	@PostMapping("/check")
//	public int checkAlbumReview(AlbumReviewVO vo) {
//		return AlbumReviewService.checkAlbumReview(vo);
//	}
	
//	@PostMapping(value="/check", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
//	public ResponseEntity<String>checkAlbumReview(@RequestBody AlbumReviewVO vo) {
//		
//		log.info("AlbumReviewVO: " + vo );
//		
//		int checkCount = service.checkAlbumReview(vo);
//		
//		log.info("AlbumReview Insert Count : " +checkCount);
//		
//		return checkCount == 1 
//				? new ResponseEntity<>("success", HttpStatus.OK)
//				: new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
	
	
			
}

