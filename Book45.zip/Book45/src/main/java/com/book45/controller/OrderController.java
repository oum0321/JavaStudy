package com.book45.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.book45.domain.Criteria;
import com.book45.domain.OrderDTO;
import com.book45.domain.OrderPageDTO;
import com.book45.domain.PageDTO;
import com.book45.service.AdminService;
import com.book45.service.MemberService;
import com.book45.service.OrderService;

import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/order/*")
public class OrderController {
   @Autowired
   private OrderService orderService;
   
   @Autowired
   private MemberService memberService;
   
   @Autowired
	private AdminService adminService;
   
   @GetMapping("/orderPage/{id}")
      public String orderPage(@PathVariable("id") String id, @RequestParam("isbn") Long isbn, @RequestParam("productNum") Long productNum, OrderPageDTO orderPage, Model model) {
         log.info("주문 페이지");
         log.info("id: " + id);
         log.info("orders: " + orderPage.getOrders());
         if (productNum == null) {
            model.addAttribute("orderBookList", orderService.getBooksInfo(orderPage.getOrders()));
            model.addAttribute("memberInfo", memberService.getMember(id));
            log.info("getBooksInfo: " + orderService.getBooksInfo(orderPage.getOrders())); 
         } else if (isbn == null) {
            model.addAttribute("orderAlbumList", orderService.getAlbumsInfo(orderPage.getOrders()));
            model.addAttribute("memberInfo", memberService.getMember(id));
            log.info("getBooksInfo: " + orderService.getBooksInfo(orderPage.getOrders())); 
         } else {
            model.addAttribute("orderBookList", orderService.getBooksInfo(orderPage.getOrders()));
            model.addAttribute("orderAlbumList", orderService.getAlbumsInfo(orderPage.getOrders()));
            model.addAttribute("memberInfo", memberService.getMember(id));
            log.info("getBooksInfo: " + orderService.getBooksInfo(orderPage.getOrders())); 
        }
        
         return "/order/orderPage";
      }
   
   @PostMapping("/orderList") 
   @ResponseBody
   public String orderPagePost(OrderDTO od, HttpServletRequest request) {
	   
	   log.info("==orderDTO==" + od);
	   
	   try {
		   log.info("뿡뿡");
	   }catch(Exception e) {
		   log.info("뿡");
	   }
	   
	   orderService.bookOrder(od);
	   orderService.albumOrder(od);
	   
	   log.info("===orderDTO===" + od);
	   return "redirect:/main";
   }
   
   /* 주문 현황 페이지 */
	@GetMapping("/orderList")
	public String orderListGET(Criteria cri, Model model) {
		
		List<OrderDTO> orderItem = adminService.getOrderList(cri);
		
		if(!orderItem.isEmpty()) {
			model.addAttribute("list", orderItem);
			model.addAttribute("pageMaker", new PageDTO(cri, adminService.getOrderTotal(cri)));
		} else {
			model.addAttribute("orderItemCheck", "empty");
		}	
		
		return "/order/orderList";
	}
}