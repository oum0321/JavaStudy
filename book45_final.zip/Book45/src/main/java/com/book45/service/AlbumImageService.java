//package com.book45.service;
//
//import java.util.List;
//
//import com.book45.domain.AlbumImageVO;
//
//public interface AlbumImageService {
//
//	public List<AlbumImageVO> getAlbumImageList(Long productNum);
//	
//}
