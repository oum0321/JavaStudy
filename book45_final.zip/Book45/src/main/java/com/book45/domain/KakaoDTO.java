package com.book45.domain;

import lombok.Data;

@Data
public class KakaoDTO {
	private Long kakaoNumber;
	private String nickname;
	private String email;
}
